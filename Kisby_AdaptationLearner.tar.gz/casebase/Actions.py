
# Action that moves an *ordered* sandwich stack from its old location
# to a new location.
#def move(state, sandwichstack, location):
#    for loc in ["UNUSED", "MAKE_BOARD", "CUT_BOARD", "PAN"]:
#

#def spread

